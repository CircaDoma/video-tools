# Firefox Camtasia Mods

## Modifications

### Text box blinking cursor

